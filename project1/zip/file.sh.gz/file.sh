file="archive"

if [ -d "$file" ]
then 
	echo "ton tai "
else 
	echo "kh ton tai "
fi
