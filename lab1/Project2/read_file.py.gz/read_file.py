import os
import json

# Đường dẫn tới thư mục
directory_path = "/home/dungluu/MyProject/test/lab1/Project2/Project2/0~85"

# Kiểm tra thư mục có tồn tại không
if os.path.exists(directory_path):
    # Duyệt qua tất cả các file trong thư mục
    for filename in os.listdir(directory_path):
        if filename.endswith(".json"):  # Chỉ xử lý file JSON
            file_path = os.path.join(directory_path, filename)
            print(f"Đang xử lý file: {file_path}")
            
            try:
                # Đọc nội dung file JSON
                with open(file_path, "r", encoding="utf-8") as file:
                    data = json.load(file)
                    print(f"Nội dung file {filename}:")
                    print(data)  # Xử lý dữ liệu JSON tại đây
            except Exception as e:
                print(f"Lỗi khi đọc file {filename}: {e}")
else:
    print(f"Thư mục không tồn tại: {directory_path}")

