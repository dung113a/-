#!/bin/bash

number=2

if [ $number -gt 8 ] 
then 
  echo "so lon hon 8"
elif [ $number -gt 5 ] 
then 
   echo "so nho hon 8"
else 
  echo " la so khac"
fi


### 
