echo "please enter one number you want"
read number
if [ $number -eq 0 ]
then 
	echo "is 0 "
elif [ $number -gt 0 ]
then
	echo "so duong"
else 
	echo "so am"
fi
