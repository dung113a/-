#!/bin/bash

# Kiểm tra tham số đầu vào
if [ -z "$1" ]; then
  echo "Usage: $0 <directory>"
  exit 1
fi

# Hàm đệ quy hiển thị cây thư mục
print_tree() {
  local prefix="$2"
  for file in "$1"/*; do
    if [ -d "$file" ]; then
      echo "${prefix}├── $(basename "$file")/"
      print_tree "$file" "${prefix}│   "
    else
      echo "${prefix}├── $(basename "$file")"
    fi
  done
}

# Gọi hàm với thư mục được truyền vào
echo "$1"
print_tree "$1" ""

