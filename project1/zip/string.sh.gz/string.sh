#!/bin/bash 

name="Alicqe"
if [ "$name" == "Alice" ]
then
    echo "xin chao Alice"
else 
    echo "you aren't Alice"
fi

